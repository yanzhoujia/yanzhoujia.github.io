### 近期因为一些原因，接口没有及时更新。给大家带来的不便表示歉意，现接口已全面更新，后续的问题请留言告诉我，感谢大家的支持！！！

### GitHub加速
国内访问地址一
```
主接口：
https://raw.iqiq.io/2hacc/TVBox/main/tvbox.json

小雅js：
https://raw.iqiq.io/2hacc/TVBox/main/drpy/xiaoya.json
```
国内访问地址二
```
主接口：
https://raw.fastgit.org/2hacc/TVBox/main/tvbox.json

小雅js：
https://raw.fastgit.org/2hacc/TVBox/main/drpy/xiaoya.json
```
国内访问备用地址一
```
主接口：
https://cdn.jsdelivr.net/gh/2hacc/TVBox@main/tvbox.json

小雅js：
https://cdn.jsdelivr.net/gh/2hacc/TVBox@main/drpy/xiaoya.json
```
国内访问备用地址二
```
主接口：
https://raw.githubusercontents.com/2hacc/TVBox/main/tvbox.json

小雅js：
https://raw.githubusercontents.com/2hacc/TVBox/main/drpy/xiaoya.json
```
国内访问备用地址三
```
主接口：
https://ghproxy.com/https://raw.githubusercontent.com/2hacc/TVBox/main/tvbox.json

小雅js：
https://ghproxy.com/https://raw.githubusercontent.com/2hacc/TVBox/main/drpy/xiaoya.json
```
